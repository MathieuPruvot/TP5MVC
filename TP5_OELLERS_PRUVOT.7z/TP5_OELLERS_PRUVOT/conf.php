<?php
	define("USER", "root"); // constante nom d'utilisateur
	define("PASS", "root"); // constante mot de passe
	define("HOST", "localhost"); // constante adresse BDD
	define("PORT", "3316"); // constante port utilisé
	define("DBNAME", "client"); // constante nom de la base
?>
